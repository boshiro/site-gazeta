<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/church/p3.jpg");

//logo
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/church/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',      'http://demo_content.tagdiv.com/Newspaper_6/church/logo-header@2x.png');
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             'http://demo_content.tagdiv.com/Newspaper_6/church/logo-mobile.png');



