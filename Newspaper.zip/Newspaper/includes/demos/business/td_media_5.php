<?php

//..
td_demo_media::add_image_to_media_gallery('td_pic_16',                   "http://demo_content.tagdiv.com/Newspaper_6/business/16.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_17',                   "http://demo_content.tagdiv.com/Newspaper_6/business/17.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_18',                   "http://demo_content.tagdiv.com/Newspaper_6/business/18.jpg");

// ads
td_demo_media::add_image_to_media_gallery('td_business_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/business/sidebar.jpg");
td_demo_media::add_image_to_media_gallery('td_business_header_ad',              "http://demo_content.tagdiv.com/Newspaper_6/business/header.png");

