<?php

// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_6/business/business_logo.png");
td_demo_media::add_image_to_media_gallery('td_logo_header_retina',      "http://demo_content.tagdiv.com/Newspaper_6/business/business_logo_retina.png");

// other images
td_demo_media::add_image_to_media_gallery('td_footer_background_image',               "http://demo_content.tagdiv.com/Newspaper_6/business/footer_bg.jpg");