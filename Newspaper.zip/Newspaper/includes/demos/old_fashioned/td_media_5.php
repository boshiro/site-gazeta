<?php
/**
 * Created by ra on 6/13/2015.
 */

//ads
td_demo_media::add_image_to_media_gallery('td_custom_ad_1',              "http://demo_content.tagdiv.com/Newspaper_6/old_fashioned/cusotm-ad-1.png");
td_demo_media::add_image_to_media_gallery('td_custom_ad_2',              "http://demo_content.tagdiv.com/Newspaper_6/old_fashioned/cusotm-ad-2.png");
td_demo_media::add_image_to_media_gallery('td_custom_ad_3',              "http://demo_content.tagdiv.com/Newspaper_6/old_fashioned/cusotm-ad-3.png");