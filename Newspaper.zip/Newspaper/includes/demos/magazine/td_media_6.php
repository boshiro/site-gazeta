<?php
td_demo_media::add_image_to_media_gallery('td_logo_footer',             'http://demo_content.tagdiv.com/Newspaper_6/magazine/logo-footer@2x.png');
td_demo_media::add_image_to_media_gallery('td_bg',                      'http://demo_content.tagdiv.com/Newspaper_6/magazine/background.png');
//ads
td_demo_media::add_image_to_media_gallery('td_header_ad',              "http://demo_content.tagdiv.com/Newspaper_6/magazine/rec728.jpg");
td_demo_media::add_image_to_media_gallery('td_sidebar_ad',             "http://demo_content.tagdiv.com/Newspaper_6/magazine/rec300.jpg");