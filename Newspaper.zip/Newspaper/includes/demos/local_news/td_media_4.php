<?php
td_demo_media::add_image_to_media_gallery('td_pic_13',                  "http://demo_content.tagdiv.com/Newspaper_6/local_news/13.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_14',                  "http://demo_content.tagdiv.com/Newspaper_6/local_news/14.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_15',                  "http://demo_content.tagdiv.com/Newspaper_6/local_news/15.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newspaper_6/local_news/p1.jpg");