<?php
td_demo_media::add_image_to_media_gallery('td_pic_7',                   "http://demo_content.tagdiv.com/Newspaper_6/politics/7.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_8',                   "http://demo_content.tagdiv.com/Newspaper_6/politics/8.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_9',                   "http://demo_content.tagdiv.com/Newspaper_6/politics/9.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_10',                  "http://demo_content.tagdiv.com/Newspaper_6/politics/10.jpg");